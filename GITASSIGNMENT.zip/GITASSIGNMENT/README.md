# This assignment is about Git and Github.

## The assignment is based on the lecture conducted on 22 July 2023, by Mr. Krish Naik.
