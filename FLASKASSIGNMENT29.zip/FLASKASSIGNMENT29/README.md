# This assignment is on flask.
## The revision session was conducted by Mr. Sunny Savita.
### Date: 29 July 2023.