from flask import Flask, request, render_template

app = Flask(__name__)


@app.route('/cal', methods=["GET", "POST"])
def math_operator():
    result = ""

    if request.method == "POST":
        operation = request.form["operation"]
        number1 = request.form["number1"]
        number2 = request.form["number2"]

        if operation == "add":
            result = int(number1) + int(number2)
        elif operation == "multiply":
            result = int(number1) * int(number2)
        elif operation == "division":
            result = int(number1) / int(number2)
        else:
            result = int(number1) - int(number2)

    return render_template("calculator.html", result=result)

if __name__ == '__main__':
    app.run(debug=True)
